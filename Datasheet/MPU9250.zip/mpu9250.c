#include <linux/module.h>
#include <linux/completion.h>
#include <linux/delay.h>
#include <linux/i2c.h>
#include <linux/slab.h>
#include <linux/gpio.h>
#include <asm/uaccess.h>
#include <linux/poll.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/input.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/timer.h>
#include <linux/hrtimer.h>
#include <linux/i2c.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/proc_fs.h>
#include <asm/uaccess.h>

#define MPU_LEN_1BYTE	1
#define MPU_LEN_2BYTE	2

#define MPU_CMD_CALIBRATION	5
#define MPU_CMD_GETDATA		6
#define MPU_CMD_FIFOCLEAR	7
#define MPU_CMD_INIT		8
#define MPU_CMD_RESET		9


#define MPU_SELF_TEST_X_GYRO 0x00                  
#define MPU_SELF_TEST_Y_GYRO 0x01                                                                          
#define MPU_SELF_TEST_Z_GYRO 0x02

/*#define MPU_X_FINE_GAIN      0x03 // [7:0] fine gain
#define MPU_Y_FINE_GAIN      0x04
#define MPU_Z_FINE_GAIN      0x05
#define MPU_XA_OFFSET_H      0x06 // User-defined trim values for accelerometer
#define MPU_XA_OFFSET_L_TC   0x07
#define MPU_YA_OFFSET_H      0x08
#define MPU_YA_OFFSET_L_TC   0x09
#define MPU_ZA_OFFSET_H      0x0A
#define MPU_ZA_OFFSET_L_TC   0x0B */

#define MPU_SELF_TEST_X_ACCEL 0x0D
#define MPU_SELF_TEST_Y_ACCEL 0x0E    
#define MPU_SELF_TEST_Z_ACCEL 0x0F

#define MPU_SELF_TEST_A      0x10

#define MPU_XG_OFFSET_H      0x13  // User-defined trim values for gyroscope
#define MPU_XG_OFFSET_L      0x14
#define MPU_YG_OFFSET_H      0x15
#define MPU_YG_OFFSET_L      0x16
#define MPU_ZG_OFFSET_H      0x17
#define MPU_ZG_OFFSET_L      0x18
#define MPU_SMPLRT_DIV       0x19
#define MPU_CONFIG           0x1A
#define MPU_GYRO_CONFIG      0x1B
#define MPU_ACCEL_CONFIG     0x1C
#define MPU_ACCEL_CONFIG2    0x1D
#define MPU_LP_ACCEL_ODR     0x1E   
#define MPU_WOM_THR          0x1F   

#define MPU_MOT_DUR          0x20  // Duration counter threshold for motion interrupt generation, 1 kHz rate, LSB = 1 ms
#define MPU_ZMOT_THR         0x21  // Zero-motion detection threshold bits [7:0]
#define MPU_ZRMOT_DUR        0x22  // Duration counter threshold for zero motion interrupt generation, 16 Hz rate, LSB = 64 ms

#define MPU_FIFO_EN          0x23
#define MPU_I2C_MST_CTRL     0x24   
#define MPU_I2C_SLV0_ADDR    0x25
#define MPU_I2C_SLV0_REG     0x26
#define MPU_I2C_SLV0_CTRL    0x27
#define MPU_I2C_SLV1_ADDR    0x28
#define MPU_I2C_SLV1_REG     0x29
#define MPU_I2C_SLV1_CTRL    0x2A
#define MPU_I2C_SLV2_ADDR    0x2B
#define MPU_I2C_SLV2_REG     0x2C
#define MPU_I2C_SLV2_CTRL    0x2D
#define MPU_I2C_SLV3_ADDR    0x2E
#define MPU_I2C_SLV3_REG     0x2F
#define MPU_I2C_SLV3_CTRL    0x30
#define MPU_I2C_SLV4_ADDR    0x31
#define MPU_I2C_SLV4_REG     0x32
#define MPU_I2C_SLV4_DO      0x33
#define MPU_I2C_SLV4_CTRL    0x34
#define MPU_I2C_SLV4_DI      0x35
#define MPU_I2C_MST_STATUS   0x36
#define MPU_INT_PIN_CFG      0x37
#define MPU_INT_ENABLE       0x38
#define MPU_DMP_INT_STATUS   0x39  // Check DMP interrupt
#define MPU_INT_STATUS       0x3A
#define MPU_ACCEL_XOUT_H     0x3B
#define MPU_ACCEL_XOUT_L     0x3C
#define MPU_ACCEL_YOUT_H     0x3D
#define MPU_ACCEL_YOUT_L     0x3E
#define MPU_ACCEL_ZOUT_H     0x3F
#define MPU_ACCEL_ZOUT_L     0x40
#define MPU_TEMP_OUT_H       0x41
#define MPU_TEMP_OUT_L       0x42
#define MPU_GYRO_XOUT_H      0x43
#define MPU_GYRO_XOUT_L      0x44
#define MPU_GYRO_YOUT_H      0x45
#define MPU_GYRO_YOUT_L      0x46
#define MPU_GYRO_ZOUT_H      0x47
#define MPU_GYRO_ZOUT_L      0x48
#define MPU_EXT_SENS_DATA_00 0x49
#define MPU_EXT_SENS_DATA_01 0x4A
#define MPU_EXT_SENS_DATA_02 0x4B
#define MPU_EXT_SENS_DATA_03 0x4C
#define MPU_EXT_SENS_DATA_04 0x4D
#define MPU_EXT_SENS_DATA_05 0x4E
#define MPU_EXT_SENS_DATA_06 0x4F
#define MPU_EXT_SENS_DATA_07 0x50
#define MPU_EXT_SENS_DATA_08 0x51
#define MPU_EXT_SENS_DATA_09 0x52
#define MPU_EXT_SENS_DATA_10 0x53
#define MPU_EXT_SENS_DATA_11 0x54
#define MPU_EXT_SENS_DATA_12 0x55
#define MPU_EXT_SENS_DATA_13 0x56
#define MPU_EXT_SENS_DATA_14 0x57
#define MPU_EXT_SENS_DATA_15 0x58
#define MPU_EXT_SENS_DATA_16 0x59
#define MPU_EXT_SENS_DATA_17 0x5A
#define MPU_EXT_SENS_DATA_18 0x5B
#define MPU_EXT_SENS_DATA_19 0x5C
#define MPU_EXT_SENS_DATA_20 0x5D
#define MPU_EXT_SENS_DATA_21 0x5E
#define MPU_EXT_SENS_DATA_22 0x5F
#define MPU_EXT_SENS_DATA_23 0x60
#define MPU_MOT_DETECT_STATUS 0x61
#define MPU_I2C_SLV0_DO      0x63
#define MPU_I2C_SLV1_DO      0x64
#define MPU_I2C_SLV2_DO      0x65
#define MPU_I2C_SLV3_DO      0x66
#define MPU_I2C_MST_DELAY_CTRL 0x67
#define MPU_SIGNAL_PATH_RESET  0x68
#define MPU_MOT_DETECT_CTRL  0x69
#define MPU_USER_CTRL        0x6A  // Bit 7 enable DMP, bit 3 reset DMP
#define MPU_PWR_MGMT_1       0x6B // Device defaults to the SLEEP mode
#define MPU_PWR_MGMT_2       0x6C
#define MPU_DMP_BANK         0x6D  // Activates a specific bank in the DMP
#define MPU_DMP_RW_PNT       0x6E  // Set read/write pointer to a specific start address in specified DMP bank
#define MPU_DMP_REG          0x6F  // Register in DMP from which to read or to which to write
#define MPU_DMP_REG_1        0x70
#define MPU_DMP_REG_2        0x71 
#define MPU_FIFO_COUNTH      0x72
#define MPU_FIFO_COUNTL      0x73
#define MPU_FIFO_R_W         0x74
#define MPU_WHO_AM_I		 0x75 // Should return 0x71
#define MPU_XA_OFFSET_H      0x77
#define MPU_XA_OFFSET_L      0x78
#define MPU_YA_OFFSET_H      0x7A
#define MPU_YA_OFFSET_L      0x7B
#define MPU_ZA_OFFSET_H      0x7D
#define MPU_ZA_OFFSET_L      0x7E

#define MPU_CALI_INDEX	20

#define MPU9255_DEVICEID	0x73
#define MPU9250_DEVICEID	0x71
#define MPU9250_TIMER		10000000

#define MPU_MAJOR_DEF	228
#define MPU_MINOR_DEF	0

#define MPU_DEV_NAME	"Gyro mpu9250"
#define MPU_DEVICE_NAME	"mpu9250"

#define AK8963_WHOIAM	0x00
#define AK8963_INFO		0x01
#define AK8963_STATUS1	0x02
#define AK8963_MEASUREMENET_LX	0x03
#define AK8963_MEASUREMENET_HX	0x04
#define AK8963_MEASUREMENET_LY	0x05
#define AK8963_MEASUREMENET_HY	0x06
#define AK8963_MEASUREMENET_LZ	0x07
#define AK8963_MEASUREMENET_HZ	0x08
#define AK8963_STATUS2	0x09
#define AK8963_CONTROL1	0x0A
#define AK8963_CONTROL2	0x0B
#define AK8963_ASTC		0x0C


#define AK8963_DEVICEID	0x48

typedef struct mpu9250_listnode
{
	void* data;
	void* next;
}mpu9250_listnode;


typedef struct
{
	mpu9250_listnode* head;
	mpu9250_listnode* LastNode;
	unsigned int index;
}mpu9250_Fifo;


struct mpu9250_platform_data 
{	
	unsigned long gpio_interrupt;	
	unsigned long gpio_ext_interrupt;
	unsigned long irqflags;
};

struct mpu9250_sensor_data
{
	short Temprature;
	short gx;
	short gy;
	short gz;
	short ax;
	short ay;
	short az;
	short mx;
	short my;
	short mz;
	char temp[2];
};

struct i2c_write
{
	char add;
	char data;
	char wait;
};

struct mpu9250_data
{
	struct i2c_client *client;
	struct i2c_client *ak8963client;
	struct mpu9250_platform_data *pdata;
//	struct mpu9250_sensor_data odata;
	struct mpu9250_sensor_data calidata;
	struct class *mpu_class;
	struct hrtimer timer;
	
	unsigned long irq;
	unsigned long gpio_interrupt;
	unsigned long gpio_ext_interrupt;
	
	struct workqueue_struct *mpu9250_wq;	
	struct work_struct  mpu9250_work;

	mpu9250_Fifo* fifo;
	
	unsigned int opendevice;
	unsigned int init;

	int accel[3];
	int gyro[3];	
};

struct i2c_write mpuinitcode[] = {
	{	.add  = MPU_PWR_MGMT_1,
		.data = 0x80,
		.wait = 50,},
	{	.add  = MPU_PWR_MGMT_1,
		.data = 0x00,
		.wait = 10,},
	{	.add  = MPU_PWR_MGMT_1,
		.data = 0x01,
		.wait = 0,},
	{	.add  = MPU_CONFIG,
		.data = 0x06,
		.wait = 10,},
	{	.add  = MPU_SMPLRT_DIV,
		.data = 0x09,		//1K / 10 = 100HZ
		.wait = 0,},
	{	.add  = MPU_GYRO_CONFIG,
		.data = 0x18,	
		.wait = 0,},
	{	.add  = MPU_ACCEL_CONFIG,
		.data = 0x18,	
		.wait = 0,},
	{	.add  = MPU_ACCEL_CONFIG2,
		.data = 0x06,	
		.wait = 0,},
	{	.add  = MPU_INT_PIN_CFG,
		.data = 0x22,		
		.wait = 0,},
	{	.add  = MPU_INT_ENABLE,
		.data = 0x01,		
		.wait = 0,},
	{	.add  = 0x00,
		.data = 0x00,
		.wait = 0,},	
};



struct mpu9250_data *mpudata;


void mpu9250_Fifo_CleanNode(mpu9250_Fifo* fifo);
void mpu9250_Reset(struct mpu9250_data *data);
void ak8963_initcode(struct mpu9250_data *data);


mpu9250_Fifo* mpu9250_Fifo_Init()
{
	mpu9250_Fifo* fifo;

	fifo = (mpu9250_Fifo*)kmalloc(sizeof(mpu9250_Fifo), GFP_KERNEL);
	memset(fifo,0,sizeof(mpu9250_Fifo));
	fifo->head = (mpu9250_listnode*)kmalloc(sizeof(mpu9250_listnode), GFP_KERNEL);
	memset(fifo->head, 0, sizeof(mpu9250_listnode));

	return fifo;
}

void mpu9250_Fifo_Delete(mpu9250_Fifo* fifo)
{
	if(fifo==NULL) return;
	
	if (fifo->head)
	{
		mpu9250_Fifo_CleanNode(fifo);
	}
	kfree(fifo);
}


int mpu9250_Fifo_PushNode(mpu9250_Fifo* fifo,char* data)
{
	mpu9250_listnode* NewNode;
	mpu9250_listnode* head = fifo->head;
	mpu9250_listnode* LastNode = fifo->LastNode;

	NewNode = (mpu9250_listnode*)kmalloc(sizeof(mpu9250_listnode), GFP_KERNEL);
	if(NewNode <= 0) return -1;
	NewNode->next = NULL;
	NewNode->data = data;

	if(head->next == NULL)
	{
		fifo->LastNode = NewNode;
		head->next = NewNode;
	}
	else
	{
		LastNode->next = NewNode;
		fifo->LastNode = NewNode;
	}
	
	return 0;
}

char* mpu9250_Fifo_PopNode(mpu9250_Fifo* fifo)
{
	mpu9250_listnode* PopNode;
	char* Data;
	mpu9250_listnode* head = fifo->head;
	
	if(head->next != NULL)
	{
		PopNode = head->next;

		head->next = PopNode->next;
		Data = PopNode->data;
		kfree(PopNode);
		
		return Data;
	}

	return NULL;
}


void mpu9250_Fifo_CleanNode(mpu9250_Fifo* fifo)
{
	char* data;

	while(1)
	{
		data = mpu9250_Fifo_PopNode(fifo);
		if(data == NULL) break;
		else 
		  kfree(data);
	}
}


void mpu9250_printNode(mpu9250_Fifo* fifo)
{
	mpu9250_listnode* Temp = fifo->head;
	int nCount = 0;
	
	while(1)
	{
		Temp = Temp->next;
		if(Temp == NULL) break;
		nCount++;
		
		//dprintf(INFO, "PrintTouch %d (%d, %d)\n",nCount,Temp->data->PositionX,Temp->data->PositionY);
	}
}


void mpu9250_initcode(struct mpu9250_data *data)
{
	int nRow, ret;
	char buf[2];
	char readbuf[2];
	
	pr_info("mpu9250 : Init Code\n");

	for(nRow=0; nRow<1000; nRow++)
	{
		buf[0] = mpuinitcode[nRow].add;
		buf[1] = mpuinitcode[nRow].data;

		if(buf[0] == 0) break;
		
		ret = i2c_master_send(data->client, buf, 2);
		if(ret <= 0) pr_info("mpu9250 : Write Failed \n");
		else		 pr_info("mpu9250 : add-0x%x data-0x%x\n",buf[0],buf[1]);

		if(mpuinitcode[nRow].wait > 0) msleep(mpuinitcode[nRow].wait);
	}
}



void mpu9250_calibration(struct mpu9250_data *data)
{
	int nRow, ret;
	int nCount;
	char ReadID;
	char buf[2];
	char readbuf[14];
	int sax, say, saz, sgx, sgy, sgz, sCount;
	short ax, ay, az, gx, gy, gz;
	
	pr_info("mpu9250 : Calibration\n");

	sax = 0;
	say = 0;
	saz = 0;
	sgx = 0;
	sgy = 0;
	sgz = 0;
	sCount = 0;
	
	for(nRow=0; nRow<80; nRow++)
	{
		nCount = 0;
		while(1)
		{
			ReadID = MPU_INT_STATUS;
			i2c_master_send(data->client, &ReadID, 1);
			i2c_master_recv(data->client, readbuf, 1);
			
			if(readbuf[0] & 0x01)
			{	
				ReadID = MPU_ACCEL_XOUT_H;

				i2c_master_send(data->client, &ReadID, 1);
				i2c_master_recv(data->client, readbuf, 14);

				if(nRow >= 40)
				{
					ax 	= (readbuf[0] << 8) + readbuf[1];
					ay 	= (readbuf[2] << 8) + readbuf[3];
					az 	= (readbuf[4] << 8) + readbuf[5];
					//temp = (readbuf[6] << 8) + readbuf[7];
					gx 	= (readbuf[8] << 8) + readbuf[9];
					gy 	= (readbuf[10] << 8) + readbuf[11];
					gz 	= (readbuf[12] << 8) + readbuf[13];

					sax += ax;
					say += ay;
					saz += az;
					sgx += gx;
					sgy += gy;
					sgz += gz;
					
					sCount ++;
					nCount++;
				}
				break;
			}
			msleep(1);
			nCount++;
			if(nCount > 100) break;
		}
	}

	sax /= sCount;
	say /= sCount;
	saz /= sCount;
	sgx /= sCount;
	sgy /= sCount;
	sgz /= sCount;

	if(saz >= 2048) saz -= 2048;
	else 			saz = -(2048 - saz);

	data->accel[0] = sax - 1;
	data->accel[1] = say - 1;
	data->accel[2] = saz - 1;

	data->gyro[0] = sgx;
	data->gyro[1] = sgy;
	data->gyro[2] = sgz;
	
	pr_info("mpu9250 : Result accel-(%d,%d,%d) gyro-(%d,%d,%d) Count-%d\n",
		sax,say,saz,sgx,sgy,sgz,sCount);
	
}



static irqreturn_t mpu9250_interrupt(int irq, void *dev_id)
{
	struct mpu9250_data *data = mpudata;

	queue_work(data->mpu9250_wq, &data->mpu9250_work);

	return IRQ_HANDLED;
}

static enum hrtimer_restart mpu9250_timer(struct hrtimer *timer)
{
	struct mpu9250_data *data = mpudata;
	
	queue_work(data->mpu9250_wq, &data->mpu9250_work);

	return HRTIMER_NORESTART;
}


static void mpu9250_work_func(struct work_struct *work)
{
	struct mpu9250_data *data = mpudata;
	struct mpu9250_sensor_data* readdata;
	char ReadID;
	char ReadBuf[14];
	char State;

	if(!data->init)
	{
		ak8963_initcode(mpudata);
		mpu9250_initcode(mpudata);
		mpu9250_calibration(mpudata);
		mpudata->init = 1;
	}
	
	if(data->opendevice)
	{	
		ReadID = MPU_INT_STATUS;

		State = 0;
		i2c_master_send(data->client, &ReadID, 1);
		i2c_master_recv(data->client, &State, 1);
		
		if(State & 0x01)
		{
			ReadID = MPU_ACCEL_XOUT_H;

			i2c_master_send(data->client, &ReadID, 1);
			i2c_master_recv(data->client, ReadBuf, 14);
				
			readdata = (struct mpu9250_sensor_data*)kmalloc(sizeof(struct mpu9250_sensor_data), GFP_KERNEL);
			
			readdata->ax 	= -((ReadBuf[0] << 8) + ReadBuf[1] - data->accel[0]);
			readdata->ay 	= ((ReadBuf[2] << 8) + ReadBuf[3] - data->accel[1]);
			readdata->az 	= (ReadBuf[4] << 8) + ReadBuf[5] - data->accel[2];
			readdata->Temprature 	= (ReadBuf[6] << 8) + ReadBuf[7];

			readdata->gx 	= ((ReadBuf[8] << 8) + ReadBuf[9] - data->gyro[0]);
			readdata->gy 	= ((ReadBuf[10] << 8) + ReadBuf[11] - data->gyro[1]);
			readdata->gz 	= (ReadBuf[12] << 8) + ReadBuf[13] - data->gyro[2];

		/*	printk("read 0x%02x, ",State);
			printk("Aeccel X:%06d Y:%06d Z:%06d, ",readdata->ax,readdata->ay,readdata->az);
			printk("Gyro X:%06d Y:%06d Z:%06d, ",readdata->gx,readdata->gy,readdata->gz);
			*/
			
			ReadID = AK8963_STATUS1;
			i2c_master_send(data->ak8963client, &ReadID, 1);
			i2c_master_recv(data->ak8963client, ReadBuf, 8);

			readdata->my 	= -((ReadBuf[1] << 8) + ReadBuf[2]);
			readdata->mx 	= -((ReadBuf[3] << 8) + ReadBuf[4]);
			readdata->mz 	= -((ReadBuf[5] << 8) + ReadBuf[6]);
			
			readdata->temp[0] = ReadBuf[0];
			readdata->temp[1] = ReadBuf[7];
			
			if(data->fifo->index < 10)
			{	
				mpu9250_Fifo_PushNode(data->fifo, (char*)readdata);
				data->fifo->index++;
				//printk("Fifo Insert\n");
			}
			else 
			{
				kfree(readdata);
			//	printk("Fifo Full\n");
			}
		}
		
	}

	if(data->opendevice) hrtimer_start(&mpudata->timer, ktime_set(0, MPU9250_TIMER), HRTIMER_MODE_REL); 
}

long mpu9250_ioctl(struct file * filp, unsigned int cmd, unsigned long arg)
{
	struct mpu9250_data *data = mpudata;
	struct mpu9250_sensor_data* outdata;

	switch(cmd){
		case MPU_CMD_RESET:
			
		break;
		case MPU_CMD_INIT:
			mpu9250_initcode(data);
		break;
		case MPU_CMD_FIFOCLEAR:
			if(data->fifo->index > 0)
			{
				mpu9250_Fifo_CleanNode(data->fifo);
				data->fifo->index = 0;
			}
		break;
		case MPU_CMD_GETDATA:
		{
			struct mpu9250_sensor_data *usrdata = (struct mpu9250_sensor_data *)arg;

			if(data->fifo->index > 0)
			{	
				data->fifo->index--;
				outdata = (struct mpu9250_sensor_data*)mpu9250_Fifo_PopNode(data->fifo);

				memcpy(usrdata,outdata,sizeof(struct mpu9250_sensor_data));
				kfree(outdata);

				return 1;
			}
			return 0;
		}
		break;
	}
	return 0;
}



static int mpu9250_open(struct inode *inode, struct file *filp )
{
	pr_info("mpu9250 : open\n");

	if(mpudata->fifo->index > 0)
	{
		mpu9250_Fifo_CleanNode(mpudata->fifo);
		mpudata->fifo->index = 0;
	}
	
	//enable_irq(mpudata->irq);
	mpudata->opendevice = 1;
	mpudata->init = 0;
	hrtimer_start(&mpudata->timer, ktime_set(0, MPU9250_TIMER), HRTIMER_MODE_REL); 
	
	return 0;
}

static int mpu9250_close(struct inode *inode, struct file *filp )
{
	hrtimer_cancel(&mpudata->timer);
	//disable_irq(mpudata->irq);
	mpudata->opendevice = 0;
	mpudata->init = 0;
	
	pr_info("mpu9250 : close\n");
	return 0;
}


static struct file_operations mpu9250_fops =
{
	.owner			= THIS_MODULE,
    .open  			= mpu9250_open,
    .unlocked_ioctl	= mpu9250_ioctl,
    .release 		= mpu9250_close,
};

static int mpu9250_CreateDriver(struct mpu9250_data* data)
{
	if( !register_chrdev( MPU_MAJOR_DEF, MPU_DEV_NAME, &mpu9250_fops ) )
    {
         pr_info("mpu9250 : rgister device %s (major=%d)\n", MPU_DEV_NAME, MPU_MAJOR_DEF );
    }
    else
    {
         pr_info("mpu9250 : unable to get major %d for %s \n", MPU_MAJOR_DEF, MPU_DEV_NAME );
         return -EBUSY;
    }

	data->mpu_class = class_create(THIS_MODULE,"mpu9250");
	device_create(data->mpu_class,NULL,MKDEV(MPU_MAJOR_DEF,MPU_MINOR_DEF),NULL,MPU_DEVICE_NAME);
	
	return 0;
}

int mpu9250_readID(struct mpu9250_data *data)
{
	int ret = -1;
	char ReadID = MPU_WHO_AM_I;
	char ReadBuf[2];
	
	i2c_master_send(data->client, &ReadID, 1);
	i2c_master_recv(data->client,ReadBuf, 1);

	if(ReadBuf[0] == MPU9255_DEVICEID || ReadBuf[0] == MPU9250_DEVICEID)
	{
		pr_info("mpu9250 : ReadID 0x%x\n",ReadBuf[0]);
		return 0;
	}
	else pr_info("mpu9250 : ReadID 0x%x Failed\n",ReadBuf[0]);
	
	return ret;
}


void mpu9250_Reset(struct mpu9250_data *data)
{
	int ret = -1;
	char write[2];

	write[0] = MPU_PWR_MGMT_1;
	write[1] = 0x80;
	
	i2c_master_send(data->client, write, 2);
	msleep(5);
}


static int mpu9250_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	int error;
	
	mpudata = kzalloc(sizeof(struct mpu9250_data), GFP_KERNEL);

	mpudata->pdata = dev_get_platdata(&client->dev);
	mpudata->client				= client;
	
	i2c_set_clientdata(client, mpudata);

	mpu9250_Reset(mpudata);
	error = mpu9250_readID(mpudata);
	if(error < 0) goto i2c_error;
	
	error = mpu9250_CreateDriver(mpudata);	
	if(error < 0) goto driver_error;

	hrtimer_init(&mpudata->timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	mpudata->timer.function = mpu9250_timer;
	
	mpudata->fifo = (mpu9250_Fifo*)mpu9250_Fifo_Init();
	mpudata->fifo->index = 0;
	mpudata->opendevice = 0;
	mpudata->init = 0;

	mpudata->mpu9250_wq = create_singlethread_workqueue("mpu9250_wq");		
	if (!mpudata->mpu9250_wq) goto irq_error;	

	INIT_WORK(&mpudata->mpu9250_work, mpu9250_work_func);
	
	pr_info("%s\n", __func__); 
	
	return 0;
irq_error:
	free_irq(mpudata->irq,mpudata);
gpio_error:
	gpio_free(mpudata->gpio_interrupt);
driver_error:
	device_destroy(mpudata->mpu_class, MKDEV(MPU_MAJOR_DEF, MPU_MINOR_DEF));
	class_destroy(mpudata->mpu_class);
	unregister_chrdev(MPU_MAJOR_DEF, MPU_DEV_NAME);	
i2c_error:
	if(mpudata) kfree(mpudata);
	pr_info("%s failed\n", __func__); 
	
	return 0;
}


static int mpu9250_remove(struct i2c_client *client)
{
	//struct mgc_data *data = i2c_get_clientdata(client);

	//device_destroy(data->mgc_class, MKDEV(MGC_MAJOR_DEF, MGC_MINOR_DEF));
	//class_destroy(data->mgc_class);
	//unregister_chrdev(MGC_MAJOR_DEF, MGC_DEV_NAME);
	
	return 0;
}


static const struct i2c_device_id mpu9250_id[] = {
	{ "mpu9250", 0 },
	{ }
};
MODULE_DEVICE_TABLE(i2c, mpu9250_id);

static struct i2c_driver mpu9250_driver = {
	.driver = {
		.name	= "mpu9250",
	},
	.probe		= mpu9250_probe,
	.remove		= mpu9250_remove,
	.id_table	= mpu9250_id,
};

void ak8963_initcode(struct mpu9250_data *data)
{
	char buf[2];
	
	pr_info("ak8963 : Init Code\n");

	buf[0] = AK8963_CONTROL1;
	buf[1] = 0x16;
	i2c_master_send(data->ak8963client, buf, 2);

}


int ak8963_readID(struct mpu9250_data *data)
{
	int ret = -1;
	char ReadID = AK8963_WHOIAM;
	char ReadBuf[2];
	
	i2c_master_send(data->ak8963client, &ReadID, 1);
	i2c_master_recv(data->ak8963client,ReadBuf, 1);

	if(ReadBuf[0] == AK8963_DEVICEID)
	{
		pr_info("ak8963 : ReadID 0x%x\n",ReadBuf[0]);
		return 0;
	}
	else pr_info("ak8963 : ReadID 0x%x Failed\n",ReadBuf[0]);
	
	return ret;
}

void ak8963_Reset(struct mpu9250_data *data)
{
	int ret = -1;
	char buf[2];

	 buf[0] = AK8963_CONTROL2;
	 buf[1] = 0x01;
	
	i2c_master_send(data->ak8963client, buf, 2);
	msleep(10);
}


static int ak8963_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	int error;
	
	mpudata->ak8963client = client;

	ak8963_Reset(mpudata);
	ak8963_readID(mpudata);
	
	pr_info("%s\n", __func__); 

	return 0;
}



static int ak8963_remove(struct i2c_client *client)
{

	return 0;
}


static const struct i2c_device_id ak8963_id[] = {
	{ "ak8963", 0 },
	{ }
};
MODULE_DEVICE_TABLE(i2c, ak8963_id);

static struct i2c_driver ak8963_driver = {
	.driver = {
		.name	= "ak8963",
	},
	.probe		= ak8963_probe,
	.remove		= ak8963_remove,
	.id_table	= ak8963_id,
};

static int __init mpu9250_init(void)
{	
	printk("mpu9250 : driver init\n");
	
	i2c_add_driver(&mpu9250_driver);
	return i2c_add_driver(&ak8963_driver);
}

static void __exit mpu9250_exit(void)
{
	i2c_del_driver(&mpu9250_driver);
}


module_init(mpu9250_init);
module_exit(mpu9250_exit);

MODULE_AUTHOR("Injea yun <tom@varikorea.co.kr>");
MODULE_DESCRIPTION("mpu9250 driver");
MODULE_LICENSE("GPL");
